#!/usr/bin/env bash

echo "Chfvat ln onpn syntaln urur, xnyb tvgh vav synt haghx xnzh: wh5g_e0g4g3_gu15_sY4t" | tr '[A-Za-z]' '[N-ZA-Mn-za-m]'
