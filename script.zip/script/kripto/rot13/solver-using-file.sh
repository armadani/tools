#!/usr/bin/env bash

cat file | tr 'A-Za-z' 'N-ZA-Mn-za-m'
