#!/usr/bin/env python
import urllib.parse

def urlencode(str):
	return urllib.parse.quote(str)

print("###################################")
print("Adeputra Armadani - URL Decoding")
print("http://github.com/armadani")
print("######################################\n")

str = input('Masukkan textnya $ ')
encoded = urlencode(str)
print("encode =>",encoded)
