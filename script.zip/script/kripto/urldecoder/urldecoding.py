#!/usr/bin/env python
import urllib.parse

def urldecode(str):
	return urllib.parse.unquote(str)

print("###################################")
print("Adeputra Armadani - URL Decoding")
print("http://github.com/armadani")
print("######################################\n")
encoded = input("Masukkin encodingnya $ ")  
decoded = urldecode(encoded)
print("decode =>",decoded)  
