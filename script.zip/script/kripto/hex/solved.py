#!/usr/bin/env python3
print("#########################")
print("##MBHC - hex decoder##")
print("####Adeputra Armadani####")
print("#########################")
hexnya = input("Masukkan hex nya : ")
proses = hexnya.decode("hex")
print(proses)
