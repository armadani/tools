import binascii
anu = input("$ ")
plain = b+str(anu)
proses = binascii.hexlify(plain, "utf-8")
print(proses)
