#!/usr/bin/python3
#soal = "0101101001101101011110000110100001011010001100110111010000110101011000100011001101010101011011100110001101101101010101010110011101011001010100110100001001101010011000100011001000111001011100110100100101000111010100100011000101011010010001110101011000111001"
soal =  input("Masukkan Binner nya = ")
hasil_temp = []

for i in range(len(soal) // 8):
  hasil_temp.append(soal[:8])
  soal = soal[8:]

hasil = ""

for j in range(len(hasil_temp)):
  temp = chr(int(hasil_temp[j], 2))
  hasil += temp

print('ASCII = ',hasil)

#hasilAkhir = base64.b64decode(hasil).decode('utf-8')
#print('Decode base64 = ',hasilAkhir)
