#!/usr/bin/env python2
import struct

print ("jika ingin dikonversi maka masukkan 4 huruf")
text = raw_input("Masukkan huruf yang mau di litle endian : ")
encode = struct.pack("<I", int(text))
print ("Litle endian dari "+text+" adalah ",str(encode))
