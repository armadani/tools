#!/usr/bin/env python
txt = raw_input("Masukkan kalimatnya = ")
rev = txt[::-1]
print(rev)
