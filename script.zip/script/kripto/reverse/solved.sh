#!/usr/bin/env bash

echo ***REVERSE***
#read reverse
echo Masukkan kalimatnya: $reverse
read reverse

echo $reverse | rev
