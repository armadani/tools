#!/usr/bin/env bash

echo XGU{Rmhvxfiv=Vzhb} | tr 'A-Za-z' 'ZYXWVUTSRQPONMLKJIHGFEDCBAzyxwvutsrqponmlkjihgfedcba'

#if A=Z, B=Y
