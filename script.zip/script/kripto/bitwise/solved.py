#!/usr/bin/env python
flag = [233, 129, 9, 5, 130, 194, 195, 39, 75, 229]
password = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
for i in range(10):
	for k in range (128):
		if flag[i]==(((((k << 5) | k >> 3)) ^ 111) & 255):
			password[i]=chr(k)
			
key=''
for a in password:
	key+=a
print (key)
