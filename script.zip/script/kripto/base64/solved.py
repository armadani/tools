#!/usr/bin/env python3
import base64
print("#########################")
print("##MBHC - base64 decoder##")
print("####Adeputra Armadani####")
print("#########################")
encode = input("masukkan encodenya :" )
proses = base64.b64decode(encode)
print(proses)
