#!/usr/bin/env python

import base64

file = open('flag.txt', 'r')
dec = file.read()
dec = base64.b64decode(dec).decode('utf-8')
print(dec)
