#!/usr/bin/env python3
import base64
print("#########################")
print("##MBHC - base64 decoder##")
print("####Adeputra Armadani####")
print("#########################")
plain = input("masukkan encodenya :" )
proses = base64.b64encode(bytes(plain, "utf-8"))
print(proses)
