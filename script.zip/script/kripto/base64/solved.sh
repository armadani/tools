#!/usr/bin/env bash

echo TUJIQ3tiYXNlNjRfSnU1dF9kM2MwZGVfeWU1fQ== | base64 -d
