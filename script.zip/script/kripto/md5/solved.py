#!/usr/bin/env python
import hashlib

m = hashlib.md5()
m.update("1")
#m = raw_input("Masukkan plaintext = ")
#m.update(m)
print m.hexdigest()

