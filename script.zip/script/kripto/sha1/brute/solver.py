import string, hashlib

ilang = "#6TV#ZDwJPNA30eG#X8b7xd#gYrRWHBS9h1Lv!#"
print("trying ..")
for x in string.printable[:-5]:
	for y in string.printable[:-5]:
		for z in string.printable[:-5]:
			for a in string.printable[:-5]:
				for b in string.printable[:-5]:
					ilang = "{}6TV{}ZDwJPNA30eG{}X8b7xd{}gYrRWHBS9h1Lv!{}".format(x,y,z,a,b)
					print("trying with {} + {} + {} + {} + {} ".format(x,y,z,a,b))
					if hashlib.sha1(hashlib.md5(ilang).hexdigest()).hexdigest() == "64c6d8504872637e8426d4f25fb0436a3f2800dd":
						print ilang
						break