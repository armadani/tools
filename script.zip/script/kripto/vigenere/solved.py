#! /usr/bin/python
# vigenere.py by Amar (2008)
import getopt, sys

def usage():
    print ' vigenere.py -k key -i file.in [-o file.out, -v,-d] '
    print
    print ' -i, --input ',
    print '    input file (Required)'
    print ' -o, --output',
    print '    output file'
    print ' -k, --key   ',
    print '    key (Required)'
    print ' -d          ',
    print '    decript'
    print ' -v          ',
    print '    verbose'

def enc(lin,k):    
    out = ord(lin) + ord(k)-ord('A')
    if (ord(lin)<=ord('Z') and out > ord('Z')) or (out > ord('z')):
        out = out - 26
    return chr(out)

def dec(lin,k):
    out = ord(lin) - ord(k)+ord('A')
    if (out < ord('A')) or (out < ord('a') and ord('a')<=ord(lin)):
        out = out + 26
    return chr(out)

def main():
    try:
        opts, args = getopt.getopt(sys.argv[1:], "dhi:k:o:v",
                                    ["help","key=","input=","output="])
    except getopt.GetoptError, err:
        # print help information and exit:
        print str(err) # will print something like "option -a not recognized"
        usage()
        sys.exit(2)
    output = feed = key = None
    verbose = decode= False
    for o, a in opts:
        if o == "-v":
            verbose = True
        elif o in ("-h", "--help"):
            usage()
            sys.exit()
        elif o == '-d':
            decode= True
        elif o in ("-k", "--key"):
            key = a
        elif o in ("-i", "--input"):
            feed = a
        elif o in ("-o", "--output"):
            output = a
        else:
            assert False, "unhandled option"
    if feed:
        filein = open(feed,'r')
        data = filein.readlines()
    else:
        print 'No input file'
        usage()
        sys.exit()
    if key:
        key = key.upper()
    else:
        print 'No key'
        usage()
        sys.exit()
    if verbose:
        print 'encoding with key-',key

    if output:
        fileout = open(output,'w')

    i=0
    for ln in data:
        line = ''
        for x in range(len(ln)):
            if (ord('a')<=ord(ln[x])<=ord('z')) or (ord('A')<=ord(ln[x])<=ord('Z')):
                if decode:
                    line += dec(ln[x],key[(i+x)%len(key)])
                else:
                    line += enc(ln[x],key[(i+x)%len(key)])
            else:
                line += ln[x]
        i=(i+len(ln))%len(key)
        if output:
            fileout.write(line)
        elif not verbose:
            print line,
        if verbose:
            print 'in >',ln,'out>',line

if __name__ == "__main__":
    main()
