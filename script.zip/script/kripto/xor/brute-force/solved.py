#!/usr/bin/env python2
import sys
#b1 = "#%(+-03558;=@CFHKNPSVX[^acfiiknqsvy{~"
#b1 = "cVRWXxdRRBgNGG8IRWdZCwRcaFNyQQ=="
#b1 = "405246606c607a316f325e637875325e796e737c"
b1 = raw_input("Masukkan xornya : ")
for a in range (1,256):
	for b in b1:
		c = ord(b)
		d = c^a
		sys.stdout.write(chr(d)) 
	print "  Kunci " +str(a)+"\n"
