#!/usr/bin/env python

#requirement : sudo apt-get install python-qrtools
# brew install zbar
#pip install pyqrcode
#pip install pyzbar


from PIL import Image
from pyzbar.pyzbar import decode
data = decode(Image.open('qr.png'))
print(data)
