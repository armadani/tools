#!/usr/bin/env bash

strings filename.exe | grep -i flag{
