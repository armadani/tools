#!/usr/bin/env python

import sys

def swap_nibbles(byte):
	return ((byte<<4) | (byte>>4)) & 0xff
 
i=open(sys.argv[1], 'rb')
o=open(sys.argv[1] + '.rev', 'wb')
o.write(''.join(map(chr, map(swap_nibbles, map(ord, i.read()[::-1])))))
i.close()
o.close()
