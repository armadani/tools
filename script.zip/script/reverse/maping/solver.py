#!/usr/bin/env python2
from pwn import *
from string import ascii_letters as pt
enc = "NLE{~3HE8M|~AH"
flag = ""
maping = {}
for c in pt:
	try:
		p = process("./splout")
		p.sendlineafter(">>", c*3)
		maping.update({c : p.recvline().strip()[-1]})
		p.close()
	except:
		pass
for e in enc:
	for x,y in zip(maping.keys(), maping.values()):
		if e == y:
			flag += x
			break
print "!F3st{%s}" % flag
