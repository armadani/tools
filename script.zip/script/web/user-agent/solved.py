#!/usr/bin/env python

import requests
re = request.get('target.com', headers={'user-agent': 'sp3rAgeNt'})
print(re.text)
