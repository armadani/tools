#!/usr/bin/env python
import requests
re = request.get('target.com', headers={'user-agent': 'agnetuser','referer',:'awesom.com'})
print(re.text)
