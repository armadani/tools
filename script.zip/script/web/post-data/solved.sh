#!/usr/bin/env bash

curl target.com -d username=admin -d password=admin
#curl target.com --data "username=admin&password=admin"
