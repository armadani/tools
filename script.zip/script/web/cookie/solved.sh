#!/usr/bin/env bash

curl 'target.com' -H 'Cookie: PHPSESSID=1nsdf2f3f3kjf3ik3at; auth={"username"+:+"pok",+"admin"+:+1,+"verifier"+:+"ff489bf5eae811c13710596f3db3369f"}' --compressed
