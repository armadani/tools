#!/usr/bin/env python
import os, sys
import Image

#Cara 1
im = Image.open("binpeg.jpg")
for y in range(0,4689):
	for x in range (0,8):
		pix = im.load()
		print pix[x,y]
