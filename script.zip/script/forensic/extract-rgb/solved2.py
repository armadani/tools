#!/usr/bin/env python
import os, sys
import Image

#Cara 2		
im = Image.open('image.gif')
rgb_im = im.convert('RGB')
r, g, b = rgb_im.getpixel((1, 1))
print r, g, b
