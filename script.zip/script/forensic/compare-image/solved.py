#!/usr/bin/env python
a = open('yuno.jpg','rb').read()
b = open('yunoOriginal.jpg','rb').read()
o = []
for i in range(len(a)):
	o.append(abs(a[i]-b[i]))

print(''.join([str(i) for i in o]).strip('0'))
