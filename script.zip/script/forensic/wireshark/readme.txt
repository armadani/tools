untuk melihat pesan terenkripsi melakukan filter di wireshark dengan "tcp.port==1337" lalu export ke dalam bentuk C array
