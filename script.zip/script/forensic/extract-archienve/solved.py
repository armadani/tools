#!/usr/bin/env python
import os
import zipfile
from pyunpack import Archive
import patoolib
file1 = 61
c = ""
for a in range(50):
	c = ""
	dest = os.listdir(os.getcwd())
	dest2 = dest[0]
	if(dest2!="ppc.py"):
		patoolib.extract_archive(dest2, outdir=".")
		os.remove(dest2)
	dest = os.listdir(os.getcwd()+"\\work_folder")
	dest = dest[0]
	with open("work_folder\\"+dest,"r") as f:
		for a in f:
			extens = a[:1]
			for d in extens:
				c+=str(ord(d))
	
	if(c=='82'):
		output = dest+".rar"
		os.rename("work_folder\\"+dest,output)
	if(c[:2]=='80'):
		output = dest+".zip"
		os.rename("work_folder\\"+dest,output)
	else:
		output = dest+".tar"
		os.rename("work_folder\\"+dest,output)

	patoolib.extract_archive(output, outdir=".")
	os.remove(output)
